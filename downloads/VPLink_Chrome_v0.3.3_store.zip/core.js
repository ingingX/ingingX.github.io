/* Local analysis: monetary totals use cents; unit prices retain source precision. */
(function (root) {
  const str = (v) => String(v ?? "").trim();
  function num(v, label, line) {
    const s = str(v).replace(/,/g, "");
    if (!s) throw Error(`第 ${line} 行「${label}」为空`);
    const n = Number(s);
    if (!Number.isFinite(n))
      throw Error(`第 ${line} 行「${label}」不是有效数字`);
    return n;
  }
  function parse(bytes) {
    const wb = XLSX.read(bytes, { type: "array", nodim: true });
    const required = [
      "门店名称",
      "设备名称",
      "货道编号",
      "商品单价",
      "订单ID",
      "商品名称",
      "品牌名称",
      "商品数量",
      "商品总价",
      "利润",
      "订单状态",
    ];
    for (const name of wb.SheetNames) {
      const grid = XLSX.utils.sheet_to_json(wb.Sheets[name], {
        header: 1,
        defval: "",
        raw: true,
      });
      const hi = grid.findIndex((r) =>
        required.every((h) =>
          r
            .map((v) => (str(v) === "货到编号" ? "货道编号" : str(v)))
            .includes(h),
        ),
      );
      if (hi < 0) continue;
      const h = grid[hi].map((v) =>
          str(v) === "货到编号" ? "货道编号" : str(v),
        ),
        i = Object.fromEntries(required.map((k) => [k, h.indexOf(k)]));
      const rows = [];
      grid.slice(hi + 1).forEach((r, j) => {
        if (r.every((v) => !str(v))) return;
        const line = hi + j + 2;
        if (!str(r[i["订单ID"]]))
          throw Error(`第 ${line} 行缺少订单ID，请检查合计行或异常行`);
        rows.push({
          id: str(r[i["订单ID"]]),
          store: str(r[i["门店名称"]]),
          device: str(r[i["设备名称"]]),
          brand: str(r[i["品牌名称"]]) || "（未填写品牌）",
          product: str(r[i["商品名称"]]) || "（未填写商品）",
          state: str(r[i["订单状态"]]),
          lane: str(r[i["货道编号"]]),
          unitPrice:
            str(r[i["商品单价"]]) === ""
              ? null
              : num(r[i["商品单价"]], "商品单价", line),
          qty: num(r[i["商品数量"]], "商品数量", line),
          amount: Math.round(num(r[i["商品总价"]], "商品总价", line) * 100),
          profit: Math.round(num(r[i["利润"]], "利润", line) * 100),
        });
      });
      if (!rows.length) throw Error("工作表只有表头，没有订单数据");
      return {
        rows,
        sheet: name,
        schemaVersion: 3,
        storeDevicePairs: storeDevices(rows),
      };
    }
    throw Error("未找到完整订单表头，需要：" + required.join("、"));
  }
  function analyze(
    rows,
    { success = true, brand = "", query = "", sort = "qty" } = {},
  ) {
    const selected = rows.filter(
      (r) =>
        (!success || r.state === "PAY_SUCCESS") &&
        (!brand || r.brand === brand) &&
        (!query ||
          `${r.brand} ${r.product}`
            .toLowerCase()
            .includes(query.toLowerCase())),
    );
    const brands = new Map(),
      products = new Map();
    const total = { qty: 0, amount: 0, profit: 0, ids: new Set() };
    for (const r of selected) {
      for (const [m, key] of [
        [brands, r.brand],
        [
          products,
          JSON.stringify([
            r.brand,
            r.product,
            str(r.lane),
            r.unitPrice ?? null,
          ]),
        ],
      ]) {
        if (!m.has(key))
          m.set(key, {
            brand: r.brand,
            product: m === products ? r.product : "",
            lane: m === products ? str(r.lane) : "",
            unitPrice: m === products ? (r.unitPrice ?? null) : null,
            qty: 0,
            amount: 0,
            profit: 0,
            ids: new Set(),
          });
        const g = m.get(key);
        g.qty += r.qty;
        g.amount += r.amount;
        g.profit += r.profit;
        g.ids.add(r.id);
      }
      total.qty += r.qty;
      total.amount += r.amount;
      total.profit += r.profit;
      total.ids.add(r.id);
    }
    const finish = (m) =>
      Array.from(m.values(), (g) => ({
        ...g,
        orders: g.ids.size,
        ids: undefined,
      })).sort(
        (a, b) =>
          b[sort] - a[sort] ||
          a.brand.localeCompare(b.brand) ||
          a.product.localeCompare(b.product),
      );
    return {
      brands: finish(brands),
      products: finish(products),
      total: {
        qty: total.qty,
        amount: total.amount,
        profit: total.profit,
        orders: total.ids.size,
        lines: selected.length,
      },
      excluded: rows.length - selected.length,
    };
  }
  function findFile(obj, depth = 0) {
    if (!obj || typeof obj !== "object" || depth > 7) return null;
    if (typeof obj.fileUrl === "string" && obj.fileUrl)
      return { url: obj.fileUrl, name: obj.fileName || "订单数据.xlsx" };
    for (const v of Object.values(obj)) {
      const f = findFile(v, depth + 1);
      if (f) return f;
    }
    return null;
  }
  const collator = new Intl.Collator("zh-CN", {
    numeric: true,
    sensitivity: "base",
  });
  function sortProducts(groups, key = "qty", direction = "desc", totalQty = 0) {
    const textKeys = new Set(["brand", "product", "lane"]);
    const keys = new Set([
      "brand",
      "product",
      "lane",
      "unitPrice",
      "qty",
      "orders",
      "amount",
      "profit",
      "share",
    ]);
    if (!keys.has(key)) key = "qty";
    const sign = direction === "asc" ? 1 : -1;
    const value = (g) =>
      key === "share" ? (totalQty ? g.qty / totalQty : null) : g[key];
    return [...groups].sort((a, b) => {
      const x = value(a),
        y = value(b);
      const empty = (v) =>
        v == null || v === "" || (typeof v === "number" && !Number.isFinite(v));
      // Missing values stay last for both ascending and descending sorting.
      if (empty(x) !== empty(y)) return empty(x) ? 1 : -1;
      const diff = empty(x)
        ? 0
        : textKeys.has(key)
          ? collator.compare(String(x), String(y))
          : Number(x) - Number(y);
      if (diff) return sign * diff;
      return (
        collator.compare(a.brand, b.brand) ||
        collator.compare(a.product, b.product) ||
        collator.compare(str(a.lane), str(b.lane)) ||
        String(a.lane).localeCompare(String(b.lane)) ||
        (a.unitPrice ?? Infinity) - (b.unitPrice ?? Infinity) ||
        0
      );
    });
  }
  function storeDevices(rows) {
    const unique = new Map();
    for (const row of rows) {
      const store = str(row.store),
        device = str(row.device);
      const key = JSON.stringify([store, device]);
      if (!unique.has(key)) unique.set(key, { store, device });
    }
    return [...unique.values()];
  }
  root.OrderCore = { parse, analyze, findFile, sortProducts, storeDevices };
})(globalThis);
