/* MV3 worker. Observe request metadata, then query the same record ourselves.
 * Only transient storage.session holds authentication headers; it is RAM-only.
 * A 30s alarm resumes a pending task if the worker is suspended between retries.
 */
importScripts("vendor/xlsx.full.min.js", "core.js", "data.js");
const RECORD = "https://www.galaxy-vplink.com/admin/exportRecord/*";
const ALARM = "vplink-export-retry";
const LIMIT = 50 * 1024 * 1024;
const running = new Set();
let retryTimer,
  discovery = Promise.resolve(),
  jobWrites = Promise.resolve();
function writeJob(expectedToken, value) {
  const operation = jobWrites
    .catch(() => {})
    .then(async () => {
      const { job } = await chrome.storage.session.get("job");
      if (expectedToken && job?.token !== expectedToken) return false;
      if (value) {
        if (!(await DataDB.isCurrent(value.token))) return false;
        await chrome.storage.session.set({ job: value });
      } else {
        await chrome.storage.session.remove("job");
        await chrome.alarms.clear(ALARM);
      }
      return true;
    });
  jobWrites = operation;
  return operation;
}
const settingsReady = chrome.storage.local
  .setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" })
  .then(() =>
    chrome.storage.session.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" }),
  );
function fileURL(raw) {
  const u = new URL(raw);
  if (
    !["www.galaxy-vplink.com", "oss.galaxy-vplink.com"].includes(u.hostname) ||
    u.username ||
    u.password ||
    u.port
  )
    throw Error("仅支持 VPLink 官方文件域名和默认端口");
  if (u.protocol === "http:" && u.hostname === "oss.galaxy-vplink.com")
    u.protocol = "https:";
  if (u.protocol !== "https:") throw Error("下载地址必须使用 HTTPS");
  return u.href;
}
async function requestBytes(url, headers = {}, limit = LIMIT) {
  const response = await fetch(url, {
    credentials: "include",
    redirect: "error",
    cache: "no-store",
    headers,
    signal: AbortSignal.timeout(25000),
  });
  if (!response.ok) throw Error("请求失败 HTTP " + response.status);
  if (Number(response.headers.get("content-length")) > limit)
    throw Error("文件或响应过大，请缩小导出范围");
  const reader = response.body.getReader(),
    chunks = [];
  let size = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > limit) {
        await reader.cancel();
        throw Error("文件超过允许大小，请缩小导出范围");
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  const bytes = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.length;
  }
  return bytes;
}
async function removeJob(token) {
  return writeJob(token, null);
}
async function valid(job) {
  const saved = (await chrome.storage.session.get("job")).job;
  const enabled = (await chrome.storage.local.get("enabled")).enabled;
  return (
    saved?.token === job.token &&
    (job.kind !== "record" || enabled !== false) &&
    (await DataDB.isCurrent(job.token))
  );
}
async function schedule(job) {
  await chrome.alarms.create(ALARM, { when: Date.now() + 30000 });
  clearTimeout(retryTimer);
  retryTimer = setTimeout(
    () => pump().catch(console.error),
    Math.max(0, job.nextAt - Date.now()),
  );
}
async function execute(job) {
  if (!(await valid(job))) {
    await removeJob(job.token);
    return;
  }
  if (Date.now() > job.expiresAt)
    throw Error("等待导出超时，请重新打开已完成的导出记录，或手动导入 Excel");
  if (job.nextAt > Date.now()) {
    await schedule(job);
    return;
  }
  // Schedule recovery before network/parse work; successful completion clears it.
  await chrome.alarms.create(ALARM, { when: Date.now() + 30000 });
  let file;
  if (job.kind === "record") {
    await DataDB.status(job.token, "正在查询导出记录…");
    const bytes = await requestBytes(
      job.recordURL,
      job.headers,
      2 * 1024 * 1024,
    );
    const json = JSON.parse(new TextDecoder().decode(bytes));
    if (json.code != null && ![0, 200, "0", "200"].includes(json.code)) {
      throw Error("导出接口返回异常，请检查登录状态或改为手动导入");
    }
    file = OrderCore.findFile(json);
    if (!file) {
      if (!(await valid(job))) return;
      job.attempts++;
      if (job.attempts >= 20)
        throw Error("尚未获得文件地址，请稍后打开已完成的导出记录");
      job.nextAt = Date.now() + 3000;
      if (!(await writeJob(job.token, job))) return;
      await DataDB.status(
        job.token,
        "等待 Excel 生成（" + job.attempts + "/20）…",
      );
      await schedule(job);
      return;
    }
  } else file = { url: job.fileURL, name: "在线订单数据.xlsx" };
  if (!(await valid(job))) return;
  await DataDB.status(job.token, "正在获取并解析 Excel…");
  const bytes = await requestBytes(fileURL(file.url));
  if (!(await valid(job))) return;
  const parsed = OrderCore.parse(bytes);
  if (
    await DataDB.commit(job.token, {
      ...parsed,
      name: String(file.name || "订单数据.xlsx"),
      time: new Date().toISOString(),
    })
  ) {
    await chrome.action.setBadgeText({ text: "✓" });
  }
  await removeJob(job.token);
}
async function pump() {
  await settingsReady;
  const { job } = await chrome.storage.session.get("job");
  if (!job || running.has(job.token)) return;
  running.add(job.token);
  try {
    await execute(job);
  } catch (error) {
    await DataDB.status(
      job.token,
      "获取失败：" + error.message + "；可以手动导入 Excel",
    );
    await removeJob(job.token);
  } finally {
    running.delete(job.token);
  }
}
async function startJob(fields, startedAt = Date.now()) {
  const token = crypto.randomUUID();
  if (!(await DataDB.begin(token, startedAt, "已发现导出任务，准备获取…")))
    return;
  const job = {
    ...fields,
    token,
    startedAt,
    attempts: 0,
    nextAt: 0,
    expiresAt: Date.now() + 120000,
  };
  if (await writeJob(null, job)) pump().catch(console.error);
}
async function observe(details) {
  await settingsReady;
  const { enabled } = await chrome.storage.local.get("enabled");
  if (enabled === false) return;
  const previous = (await chrome.storage.session.get("job")).job;
  if (
    previous?.kind === "record" &&
    previous.recordURL === details.url &&
    (await DataDB.isCurrent(previous.token))
  )
    return;
  const headers = Object.fromEntries(
    (details.requestHeaders || [])
      .filter((h) =>
        /^(authorization|token|x-token|x-auth-token|x-csrf-token|x-xsrf-token|accept-language)$/i.test(
          h.name,
        ),
      )
      .map((h) => [h.name, h.value || ""]),
  );
  await startJob(
    { kind: "record", recordURL: details.url, headers },
    details.timeStamp,
  );
}
chrome.webRequest.onBeforeSendHeaders.addListener(
  (details) => {
    if (
      details.tabId < 0 ||
      details.method !== "GET" ||
      !/^\/admin\/exportRecord\/\d+\/?$/.test(new URL(details.url).pathname)
    )
      return;
    discovery = discovery.then(() => observe(details)).catch(console.error);
  },
  { urls: [RECORD] },
  ["requestHeaders"],
);
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM) pump().catch(console.error);
});
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (
    sender.id !== chrome.runtime.id ||
    !sender.url?.startsWith(chrome.runtime.getURL(""))
  )
    return false;
  if (!["url", "toggle", "cancelBackground"].includes(message?.type))
    return false;
  (async () => {
    await settingsReady;
    if (message.type === "url")
      await startJob({ kind: "file", fileURL: fileURL(message.url) });
    if (message.type === "toggle") {
      await chrome.storage.local.set({ enabled: !!message.enabled });
      if (!message.enabled) {
        const { job } = await chrome.storage.session.get("job");
        if (job?.kind === "record" && (await DataDB.isCurrent(job.token))) {
          const token = crypto.randomUUID();
          await DataDB.begin(
            token,
            Date.now(),
            "已关闭自动捕获；仍可手动导入 Excel",
          );
          await removeJob(job.token);
        }
      }
    }
    if (message.type === "cancelBackground") {
      const { job } = await chrome.storage.session.get("job");
      if (job && !(await DataDB.isCurrent(job.token)))
        await removeJob(job.token);
      await chrome.action.setBadgeText({ text: "" });
    }
    return { ok: true };
  })().then(respond, (error) => respond({ ok: false, error: error.message }));
  return true;
});
function configurePanel() {
  return chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
}
chrome.runtime.onInstalled.addListener(() =>
  configurePanel().catch(console.error),
);
chrome.runtime.onStartup.addListener(() =>
  configurePanel().catch(console.error),
);
configurePanel().catch(console.error);
pump().catch(console.error);
