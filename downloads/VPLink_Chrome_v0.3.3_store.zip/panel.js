const $ = (id) => document.getElementById(id);
let dataset = null,
  result = null;
const money = (n) =>
  (n / 100).toLocaleString("zh-CN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
let productSort = { key: "lane", direction: "asc" };
let productColumnOrder = OrderReport.normalizeColumnOrder();
let layoutRevision = 0,
  layoutPending = 0,
  layoutWrites = Promise.resolve();
function syncColumnButtons() {
  const index = productColumnOrder.indexOf($("column-select").value);
  $("column-earlier").disabled = index <= 0;
  $("column-later").disabled =
    index < 0 || index >= productColumnOrder.length - 1;
}
function renderColumnControls() {
  const selected = $("column-select").value;
  $("column-select").replaceChildren();
  for (const column of OrderReport.getProductColumns(productColumnOrder)) {
    $("column-select").append(new Option(column.label, column.key));
  }
  $("column-select").value = productColumnOrder.includes(selected)
    ? selected
    : productColumnOrder[0];
  syncColumnButtons();
}
async function saveColumnOrder() {
  const revision = ++layoutRevision;
  layoutPending = revision;
  const snapshot = [...productColumnOrder];
  const write = layoutWrites
    .catch(() => {})
    .then(() => chrome.storage.local.set({ productColumnOrder: snapshot }));
  layoutWrites = write;
  try {
    await write;
    if (layoutPending === revision)
      $("column-status").textContent = "列顺序已保存，Excel 导出沿用当前布局。";
  } catch (error) {
    if (layoutPending === revision)
      $("column-status").textContent = "列顺序未保存：" + error.message;
  } finally {
    if (layoutPending === revision) layoutPending = 0;
  }
}
async function moveColumn(offset) {
  const index = productColumnOrder.indexOf($("column-select").value),
    target = index + offset;
  if (index < 0 || target < 0 || target >= productColumnOrder.length) return;
  [productColumnOrder[index], productColumnOrder[target]] = [
    productColumnOrder[target],
    productColumnOrder[index],
  ];
  render();
  await saveColumnOrder();
}
function table(id, groups, product) {
  const table = $(id),
    columns = product
      ? OrderReport.getProductColumns(productColumnOrder)
      : OrderReport.brandColumns;
  table.replaceChildren();
  const head = document.createElement("thead"),
    header = document.createElement("tr");
  for (const column of columns) {
    const th = document.createElement("th");
    if (column.type === "text") th.className = "text";
    if (product) {
      const active = productSort.key === column.key;
      th.setAttribute(
        "aria-sort",
        active
          ? productSort.direction === "asc"
            ? "ascending"
            : "descending"
          : "none",
      );
      const button = document.createElement("button");
      button.type = "button";
      button.className = "sort-header";
      button.dataset.sortKey = column.key;
      button.textContent =
        column.label +
        (active ? (productSort.direction === "asc" ? " ▲" : " ▼") : " ↕");
      button.title = "点击按" + column.label + "排序，再次点击切换升序/降序";
      button.onclick = () => {
        productSort = {
          key: column.key,
          direction: active
            ? productSort.direction === "asc"
              ? "desc"
              : "asc"
            : column.type === "text"
              ? "asc"
              : "desc",
        };
        render();
      };
      th.append(button);
    } else th.textContent = column.label;
    header.append(th);
  }
  head.append(header);
  table.append(head);
  const body = document.createElement("tbody");
  for (const group of groups) {
    const row = document.createElement("tr");
    for (const column of columns) {
      const cell = document.createElement("td");
      cell.textContent = OrderReport.display(group, column, result.total.qty);
      if (column.type === "text") cell.className = "text";
      row.append(cell);
    }
    body.append(row);
  }
  if (!groups.length) {
    const row = document.createElement("tr"),
      cell = document.createElement("td");
    cell.colSpan = columns.length;
    cell.textContent = "暂无匹配数据";
    row.append(cell);
    body.append(row);
  }
  table.append(body);
}
function render() {
  renderColumnControls();
  $("brand-heading").textContent = OrderReport.title("品牌汇总", dataset);
  $("product-heading").textContent = OrderReport.title("商品汇总", dataset);
  result = OrderCore.analyze(dataset?.rows || [], {
    success: $("success").checked,
    brand: $("brand").value,
    query: $("query").value.trim(),
    sort: $("sort").value === "lane" ? "qty" : $("sort").value,
  });
  result.products = OrderCore.sortProducts(
    result.products,
    productSort.key,
    productSort.direction,
    result.total.qty,
  );
  const t = result.total;
  $("cards").replaceChildren();
  for (const [label, v] of [
    ["销量", t.qty],
    ["去重订单数", t.orders],
    ["商品总价", money(t.amount)],
    ["系统利润", money(t.profit)],
  ]) {
    const div = document.createElement("div");
    div.className = "card";
    const small = document.createElement("span");
    small.textContent = label;
    const b = document.createElement("strong");
    b.textContent = v;
    div.append(small, b);
    $("cards").append(div);
  }
  table("brands", result.brands, false);
  table("products", result.products, true);
  $("note").textContent =
    `当前 ${t.lines} 条商品记录；${result.excluded} 条因状态、品牌或搜索条件未纳入。`;
  $("download").disabled = !t.lines;
}
let refreshNumber = 0;
async function refresh() {
  const id = ++refreshNumber;
  const [settings, current, stored] = await Promise.all([
    chrome.storage.local.get(["enabled", "productColumnOrder"]),
    DataDB.read("current"),
    DataDB.read("dataset"),
  ]);
  if (id !== refreshNumber) return;
  $("auto").checked = settings.enabled !== false;
  $("status").textContent =
    current?.status || "请选择 Excel，或在 VPLink 网页导出。";
  const savedOrder = OrderReport.normalizeColumnOrder(
    settings.productColumnOrder,
  );
  const layoutChanged =
    !layoutPending &&
    JSON.stringify(savedOrder) !== JSON.stringify(productColumnOrder);
  if (layoutChanged) productColumnOrder = savedOrder;
  if (dataset?.time !== stored?.time) {
    dataset = stored || null;
    const old = $("brand").value;
    $("brand").replaceChildren(new Option("全部品牌", ""));
    for (const brand of [
      ...new Set((dataset?.rows || []).map((row) => row.brand)),
    ].sort()) {
      $("brand").append(new Option(brand, brand));
    }
    $("brand").value = [...$("brand").options].some((o) => o.value === old)
      ? old
      : "";
    $("source").textContent = dataset
      ? `${dataset.name} · ${dataset.sheet} · ${new Date(dataset.time).toLocaleString()}`
      : "";
    const needsReimport = dataset?.rows.some(
      (row) =>
        !("lane" in row) ||
        !("unitPrice" in row) ||
        !("store" in row) ||
        !("device" in row),
    );
    $("schema-note").hidden = !needsReimport;
    render();
  } else if (layoutChanged) render();
}
async function send(m) {
  const r = await chrome.runtime.sendMessage(m);
  await refresh();
  if (r && !r.ok) $("status").textContent = r.error;
}
$("file").onchange = async (event) => {
  const file = event.target.files[0];
  if (!file) return;
  const token = crypto.randomUUID();
  try {
    await DataDB.begin(token, Date.now(), "正在解析 Excel…");
    if (file.size > 50 * 1024 * 1024) throw Error("文件不能超过 50MB");
    await chrome.runtime.sendMessage({ type: "cancelBackground" });
    // File bytes never cross runtime.sendMessage (Chromium serializes messages as JSON).
    const parsed = OrderCore.parse(await file.arrayBuffer());
    if (
      await DataDB.commit(token, {
        ...parsed,
        name: file.name,
        time: new Date().toISOString(),
      })
    ) {
      await chrome.action.setBadgeText({ text: "✓" });
    }
  } catch (error) {
    await DataDB.status(token, "导入失败：" + error.message);
    $("status").textContent = error.message;
  } finally {
    $("file").value = "";
    await refresh();
  }
};
$("fetch").onclick = () => send({ type: "url", url: $("url").value.trim() });
$("auto").onchange = () => send({ type: "toggle", enabled: $("auto").checked });
$("clear").onclick = async () => {
  await DataDB.clear();
  await chrome.runtime.sendMessage({ type: "cancelBackground" });
  await refresh();
};
for (const id of ["brand", "success"]) $(id).onchange = render;
$("sort").onchange = () => {
  productSort = {
    key: $("sort").value,
    direction: $("sort").value === "lane" ? "asc" : "desc",
  };
  render();
};
$("query").oninput = render;
$("download").onclick = () => {
  if (!result?.total.lines || !dataset) return;
  const book = OrderReport.workbook(result, dataset, {
    success: $("success").checked,
    brand: $("brand").value,
    query: $("query").value,
    productSort,
    productColumnOrder,
  });
  XLSX.writeFile(book, OrderReport.filename(dataset));
};
$("column-select").onchange = syncColumnButtons;
$("column-earlier").onclick = () => moveColumn(-1);
$("column-later").onclick = () => moveColumn(1);
$("column-reset").onclick = async () => {
  productColumnOrder = OrderReport.normalizeColumnOrder();
  render();
  await saveColumnOrder();
};
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local") refresh();
});
refresh()
  .then(render)
  .catch((error) => {
    $("status").textContent = "初始化失败：" + error.message;
  });
