/* Shared IndexedDB storage. Binary files and credentials are never stored here. */
(function (root) {
  let opening;
  function open() {
    if (!opening)
      opening = new Promise((resolve, reject) => {
        const request = indexedDB.open("vplink-analysis", 1);
        request.onupgradeneeded = () =>
          request.result.createObjectStore("state");
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => {
          opening = null;
          reject(request.error);
        };
      });
    return opening;
  }
  async function read(key) {
    const db = await open();
    return new Promise((resolve, reject) => {
      const request = db.transaction("state").objectStore("state").get(key);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
  async function change(operation) {
    const db = await open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction("state", "readwrite"),
        store = tx.objectStore("state");
      let result = false;
      const request = store.get("current");
      request.onsuccess = () => {
        result = operation(store, request.result);
      };
      tx.oncomplete = () => resolve(result);
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error || Error("数据写入已取消"));
    });
  }
  async function notify() {
    await chrome.storage.local.set({ revision: crypto.randomUUID() });
  }
  const api = {
    async begin(token, startedAt, status) {
      const changed = await change((store, old) => {
        if (old && old.startedAt > startedAt) return false;
        store.put({ token, startedAt, status }, "current");
        return true;
      });
      if (changed) await notify();
      return changed;
    },
    async status(token, status) {
      const changed = await change((store, old) => {
        if (old?.token !== token) return false;
        store.put({ ...old, status }, "current");
        return true;
      });
      if (changed) await notify();
      return changed;
    },
    async commit(token, data) {
      const changed = await change((store, old) => {
        if (old?.token !== token) return false;
        store.put(data, "dataset");
        store.put(
          { ...old, status: "分析完成：" + data.rows.length + " 条商品记录" },
          "current",
        );
        return true;
      });
      if (changed) await notify();
      return changed;
    },
    async clear() {
      const token = crypto.randomUUID();
      await change((store) => {
        store.delete("dataset");
        store.put(
          { token, startedAt: Date.now(), status: "已清除数据" },
          "current",
        );
        return true;
      });
      await notify();
    },
    async isCurrent(token) {
      return (await read("current"))?.token === token;
    },
    read,
  };
  root.DataDB = api;
})(globalThis);
