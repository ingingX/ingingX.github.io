/* One column definition drives both the UI and XLSX export. No binary messaging. */
(function (root) {
  const brandColumns = [
    { key: "brand", label: "品牌名称", type: "text", width: 18 },
    { key: "qty", label: "销量", type: "number", width: 12 },
    { key: "orders", label: "去重订单数", type: "number", width: 14 },
    { key: "amount", label: "商品总价", type: "money", width: 16 },
    { key: "profit", label: "系统利润", type: "money", width: 16 },
    { key: "share", label: "销量占比", type: "percent", width: 14 },
  ];
  const productColumns = [
    { key: "lane", label: "货道编号", type: "text", width: 14 },
    brandColumns[0],
    { key: "product", label: "商品名称", type: "text", width: 36 },
    brandColumns[1],
    { key: "unitPrice", label: "商品单价", type: "price", width: 16 },
    brandColumns[2],
    ...brandColumns.slice(3),
  ];
  function normalizeColumnOrder(order) {
    const valid = new Set(productColumns.map((column) => column.key)),
      result = [];
    if (Array.isArray(order)) {
      for (const key of order)
        if (valid.has(key) && !result.includes(key)) result.push(key);
    }
    for (const key of valid) if (!result.includes(key)) result.push(key);
    return result;
  }
  function getProductColumns(order) {
    const byKey = new Map(productColumns.map((column) => [column.key, column]));
    return normalizeColumnOrder(order).map((key) => byKey.get(key));
  }
  function raw(group, column, totalQty) {
    if (column.key === "share") return totalQty ? group.qty / totalQty : null;
    const value = group[column.key];
    return column.type === "money" ? value / 100 : (value ?? null);
  }
  function display(group, column, totalQty) {
    const value = raw(group, column, totalQty);
    if (value == null || value === "") return "—";
    if (column.type === "percent") return (value * 100).toFixed(1) + "%";
    if (column.type === "money" || column.type === "price") {
      return value.toLocaleString("zh-CN", {
        minimumFractionDigits: 2,
        maximumFractionDigits: column.type === "price" ? 6 : 2,
      });
    }
    return String(value);
  }
  function contextLabel(dataset) {
    if (!dataset?.rows?.length) return "";
    const pairs =
      dataset.storeDevicePairs || OrderCore.storeDevices(dataset.rows);
    return pairs
      .map(
        (pair) =>
          `${pair.store || "（未填写门店）"}=${pair.device || "（未填写设备）"}`,
      )
      .join("；");
  }
  function title(name, dataset) {
    const context = contextLabel(dataset);
    return context ? name + "_" + context : name;
  }
  function filename(dataset, date = new Date().toISOString().slice(0, 10)) {
    const clean = (value) =>
      String(value)
        .replace(/[<>:"/\\|?*\u0000-\u001f]/g, "_")
        .replace(/\s+/g, " ")
        .trim()
        .replace(/[. ]+$/g, "");
    const pairs =
      dataset?.storeDevicePairs || OrderCore.storeDevices(dataset?.rows || []);
    const labels = pairs.length
      ? pairs.map((pair) => ({
          store: clean(pair.store || "（未填写门店）"),
          device: clean(pair.device || "（未填写设备）"),
        }))
      : [{ store: "未导入门店", device: "未导入设备" }];
    const prefix = "品牌商品统计_",
      suffix = "_" + date + ".xlsx",
      encoder = new TextEncoder();
    const label = labels
      .map((pair) => pair.store + "=" + pair.device)
      .join("；");
    const complete = prefix + label + suffix;
    if (complete.length <= 200 && encoder.encode(complete).length <= 220)
      return complete;
    // Retain both a store and a device even when the filename must be shortened.
    // All complete pairs remain in row 1 of every worksheet.
    const more = labels.length > 1 ? "；等" + labels.length + "组" : "";
    const budget = 160 - encoder.encode(more).length - 1;
    const first = labels[0],
      storeSize = encoder.encode(first.store).length,
      deviceSize = encoder.encode(first.device).length;
    const deviceBudget = Math.min(
      deviceSize,
      budget - Math.min(storeSize, Math.floor(budget / 2)),
    );
    const shorten = (text, maxBytes) => {
      if (encoder.encode(text).length <= maxBytes) return text;
      let result = "";
      for (const character of text) {
        if (encoder.encode(result + character + "…").length > maxBytes) break;
        result += character;
      }
      return result + "…";
    };
    return (
      prefix +
      shorten(first.store, budget - deviceBudget) +
      "=" +
      shorten(first.device, deviceBudget) +
      more +
      suffix
    );
  }
  function titleRow(sheet, columns, heading) {
    sheet["!merges"] = [{ s: { r: 0, c: 0 }, e: { r: 0, c: columns - 1 } }];
    sheet["!rows"] = [{ hpt: 32 }];
    sheet.A1 = { t: "s", v: heading };
  }
  function workbook(result, dataset, filters) {
    const wb = XLSX.utils.book_new();
    for (const [name, groups, columns] of [
      ["品牌汇总", result.brands, brandColumns],
      [
        "商品汇总",
        result.products,
        getProductColumns(filters.productColumnOrder),
      ],
    ]) {
      const values = [
        [title(name, dataset)],
        columns.map((c) => c.label),
        ...groups.map((g) => columns.map((c) => raw(g, c, result.total.qty))),
      ];
      const sheet = XLSX.utils.aoa_to_sheet(values);
      sheet["!cols"] = columns.map((c) => ({ wch: c.width }));
      sheet["!autofilter"] = {
        ref: XLSX.utils.encode_range({
          s: { r: 1, c: 0 },
          e: { r: values.length - 1, c: columns.length - 1 },
        }),
      };
      for (let r = 2; r < values.length; r++) {
        columns.forEach((c, i) => {
          const cell = sheet[XLSX.utils.encode_cell({ r, c: i })];
          if (!cell) return;
          if (c.type === "money") cell.z = "#,##0.00";
          if (c.type === "price") cell.z = "#,##0.00####";
          if (c.type === "percent") cell.z = "0.0%";
          if (c.type === "text") cell.z = "@";
        });
      }
      titleRow(sheet, columns.length, title(name, dataset));
      if (name === "商品汇总") delete sheet["!merges"];
      XLSX.utils.book_append_sheet(wb, sheet, name);
    }
    const label =
      productColumns.find((c) => c.key === filters.productSort.key)?.label ||
      "销量";
    const notes = [
      [title("统计口径", dataset)],
      ["统计口径", "内容"],
      ["版本", "Chrome 0.3.3"],
      ["来源", dataset.name],
      ["工作表", dataset.sheet],
      ["导入时间", dataset.time],
      ["门店与设备（原表范围）", contextLabel(dataset)],
      ["状态过滤", filters.success ? "PAY_SUCCESS" : "全部状态"],
      ["品牌", filters.brand || "全部"],
      ["搜索", filters.query],
      [
        "商品分组",
        "品牌名称＋商品名称＋货道编号＋商品单价；不同货道或单价分行。",
      ],
      [
        "商品排序",
        label + (filters.productSort.direction === "asc" ? " 升序" : " 降序"),
      ],
      [
        "商品列序",
        getProductColumns(filters.productColumnOrder)
          .map((column) => column.label)
          .join("、"),
      ],
      ["销量", result.total.qty],
      ["去重订单数", result.total.orders],
      ["商品总价", result.total.amount / 100],
      ["系统利润", result.total.profit / 100],
      [
        "说明",
        "销量累加商品数量；金额累加商品总价；利润使用原表字段；订单ID按组去重，跨组不可相加。货道编号为文本、商品单价为原表数值，不求和、不平均；空值留空。金额单位沿用源表。",
      ],
    ];
    const sheet = XLSX.utils.aoa_to_sheet(notes);
    sheet["!cols"] = [{ wch: 20 }, { wch: 100 }];
    titleRow(sheet, 2, title("统计口径", dataset));
    XLSX.utils.book_append_sheet(wb, sheet, "统计口径");
    return wb;
  }
  root.OrderReport = {
    brandColumns,
    productColumns,
    normalizeColumnOrder,
    getProductColumns,
    raw,
    display,
    workbook,
    contextLabel,
    title,
    filename,
  };
})(globalThis);
